# Holst ProGuard rules
-keep class com.holst.growth.** { *; }
