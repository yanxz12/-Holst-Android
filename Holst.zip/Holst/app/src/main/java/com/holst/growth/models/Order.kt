package com.holst.growth.models

data class Order(
    val id: String,
    val serviceId: String,
    val serviceName: String,
    val platform: Platform,
    val link: String,
    val quantity: Int,
    val customComment: String? = null,
    val status: OrderStatus,
    val createdAt: Long,
    val message: String = ""
)

enum class OrderStatus {
    PENDING, PROCESSING, COMPLETED, FAILED
}
