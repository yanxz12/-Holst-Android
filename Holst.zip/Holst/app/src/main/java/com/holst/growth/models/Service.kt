package com.holst.growth.models

enum class Platform {
    TIKTOK, INSTAGRAM
}

data class ServiceItem(
    val id: String,
    val platform: Platform,
    val name: String,
    val description: String,
    val minOrder: Int,
    val maxOrder: Int,
    val supportsCustomComment: Boolean = false
)

object ServiceCatalog {
    val tiktok = listOf(
        ServiceItem("tt_followers", Platform.TIKTOK, "Followers", "Tambah followers TikTok", 100, 50000),
        ServiceItem("tt_likes", Platform.TIKTOK, "Likes", "Tambah likes video", 50, 100000),
        ServiceItem("tt_like_comments", Platform.TIKTOK, "Like Comments", "Like komentar tertentu", 10, 5000),
        ServiceItem("tt_views", Platform.TIKTOK, "Views", "Tambah views video", 1000, 1000000),
        ServiceItem("tt_shares", Platform.TIKTOK, "Shares", "Tambah shares", 50, 20000),
        ServiceItem("tt_favorites", Platform.TIKTOK, "Favorites", "Tambah favorites", 50, 20000),
        ServiceItem("tt_live", Platform.TIKTOK, "Live Stream", "Viewers live stream", 50, 10000),
        ServiceItem("tt_reposts", Platform.TIKTOK, "Reposts", "Tambah reposts", 20, 10000)
    )

    val instagram = listOf(
        ServiceItem("ig_followers", Platform.INSTAGRAM, "Followers", "Tambah followers Instagram", 100, 50000),
        ServiceItem("ig_likes", Platform.INSTAGRAM, "Likes", "Tambah likes post", 50, 100000),
        ServiceItem("ig_like_comments", Platform.INSTAGRAM, "Like Comments", "Like komentar", 10, 5000),
        ServiceItem("ig_comments", Platform.INSTAGRAM, "Comments", "Komentar custom sesuai request", 5, 2000, supportsCustomComment = true),
        ServiceItem("ig_saves", Platform.INSTAGRAM, "Saves", "Tambah saves", 50, 20000),
        ServiceItem("ig_shares", Platform.INSTAGRAM, "Shares", "Tambah shares", 20, 10000),
        ServiceItem("ig_reposts", Platform.INSTAGRAM, "Reposts", "Tambah reposts", 20, 10000)
    )

    fun findById(id: String): ServiceItem? {
        return (tiktok + instagram).find { it.id == id }
    }
}
