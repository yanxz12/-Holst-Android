package com.holst.growth.ui.theme

import androidx.compose.ui.graphics.Color

val GraphiteBlack = Color(0xFF0E0E10)
val GraphiteDark = Color(0xFF232327)
val GraphiteMid = Color(0xFF3E3E45)
val GraphiteGray = Color(0xFF63636E)
val GraphiteSoft = Color(0xFF9A9AA6)
val GraphiteLight = Color(0xFFC9C9D2)
val GraphiteWhite = Color(0xFFF2F2F5)
