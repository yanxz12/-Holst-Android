package com.holst.growth.data

import com.holst.growth.models.Order
import com.holst.growth.models.OrderStatus
import com.holst.growth.models.ServiceCatalog
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

interface GrowthRepository {
    val orders: StateFlow<List<Order>>
    suspend fun placeOrder(
        serviceId: String,
        link: String,
        quantity: Int,
        customComment: String? = null
    ): Result<Order>
}

class DummyGrowthRepository : GrowthRepository {

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    override val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    override suspend fun placeOrder(
        serviceId: String,
        link: String,
        quantity: Int,
        customComment: String?
    ): Result<Order> {
        delay(1400)

        val service = ServiceCatalog.findById(serviceId)
            ?: return Result.failure(Exception("Service tidak ditemukan"))

        if (quantity < service.minOrder || quantity > service.maxOrder) {
            return Result.failure(
                Exception("Jumlah harus antara ${service.minOrder} - ${service.maxOrder}")
            )
        }

        if (link.isBlank()) {
            return Result.failure(Exception("Link / username wajib diisi"))
        }

        val order = Order(
            id = "HOLST-${UUID.randomUUID().toString().take(8).uppercase()}",
            serviceId = serviceId,
            serviceName = service.name,
            platform = service.platform,
            link = link.trim(),
            quantity = quantity,
            customComment = customComment?.takeIf { it.isNotBlank() },
            status = OrderStatus.PROCESSING,
            createdAt = System.currentTimeMillis(),
            message = "Order diterima dan sedang diproses"
        )

        _orders.value = listOf(order) + _orders.value
        return Result.success(order)
    }
}
