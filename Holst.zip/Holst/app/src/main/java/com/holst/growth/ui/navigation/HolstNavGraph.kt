package com.holst.growth.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.holst.growth.data.DummyGrowthRepository
import com.holst.growth.ui.screens.HistoryScreen
import com.holst.growth.ui.screens.HomeScreen
import com.holst.growth.ui.screens.OrderScreen

object Routes {
    const val HOME = "home"
    const val ORDER = "order/{serviceId}"
    const val HISTORY = "history"

    fun order(serviceId: String) = "order/$serviceId"
}

@Composable
fun HolstNavGraph() {
    val navController = rememberNavController()
    val repository = remember { DummyGrowthRepository() }

    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onServiceClick = { serviceId ->
                    navController.navigate(Routes.order(serviceId))
                },
                onHistoryClick = {
                    navController.navigate(Routes.HISTORY)
                }
            )
        }

        composable(
            route = Routes.ORDER,
            arguments = listOf(navArgument("serviceId") { type = NavType.StringType })
        ) { backStackEntry ->
            val serviceId = backStackEntry.arguments?.getString("serviceId") ?: return@composable
            OrderScreen(
                serviceId = serviceId,
                repository = repository,
                onBack = { navController.popBackStack() },
                onOrderSuccess = {
                    // optional: bisa auto pindah ke history
                }
            )
        }

        composable(Routes.HISTORY) {
            HistoryScreen(
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
