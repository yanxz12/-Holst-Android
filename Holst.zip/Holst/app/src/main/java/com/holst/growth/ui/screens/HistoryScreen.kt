package com.holst.growth.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.holst.growth.data.GrowthRepository
import com.holst.growth.models.OrderStatus
import com.holst.growth.ui.components.HolstCard
import com.holst.growth.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(
    repository: GrowthRepository,
    onBack: () -> Unit
) {
    val orders by repository.orders.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp)
                .padding(top = 48.dp, bottom = 12.dp)
        ) {
            Text(
                text = "←  Kembali",
                color = GraphiteSoft,
                fontSize = 14.sp,
                modifier = Modifier
                    .padding(bottom = 20.dp)
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { onBack() }
            )
            Text(
                text = "History",
                color = GraphiteWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                text = "${orders.size} order",
                color = GraphiteSoft,
                fontSize = 13.sp
            )
        }

        if (orders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(22.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada order",
                    color = GraphiteGray,
                    fontSize = 15.sp
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 22.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(orders) { order ->
                    HolstCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = order.serviceName,
                                color = GraphiteWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                            StatusChip(order.status)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = order.platform.name.lowercase(),
                            color = GraphiteSoft,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = order.link,
                            color = GraphiteLight,
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Qty: ${order.quantity}  •  ${formatTime(order.createdAt)}",
                            color = GraphiteGray,
                            fontSize = 12.sp
                        )
                        order.customComment?.let {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "\"$it\"",
                                color = GraphiteSoft,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = order.id,
                            color = GraphiteGray,
                            fontSize = 11.sp
                        )
                    }
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }
}

@Composable
private fun StatusChip(status: OrderStatus) {
    val label = when (status) {
        OrderStatus.PENDING -> "Pending"
        OrderStatus.PROCESSING -> "Processing"
        OrderStatus.COMPLETED -> "Completed"
        OrderStatus.FAILED -> "Failed"
    }
    Text(
        text = label,
        color = GraphiteSoft,
        fontSize = 12.sp
    )
}

private fun formatTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
