package com.holst.growth.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.holst.growth.data.GrowthRepository
import com.holst.growth.models.ServiceCatalog
import com.holst.growth.ui.components.HolstButton
import com.holst.growth.ui.components.HolstCard
import com.holst.growth.ui.components.HolstTextField
import com.holst.growth.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun OrderScreen(
    serviceId: String,
    repository: GrowthRepository,
    onBack: () -> Unit,
    onOrderSuccess: () -> Unit
) {
    val service = ServiceCatalog.findById(serviceId) ?: return

    var link by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var customComment by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp)
                .padding(top = 48.dp, bottom = 8.dp)
        ) {
            Text(
                text = "←  Kembali",
                color = GraphiteSoft,
                fontSize = 14.sp,
                modifier = Modifier
                    .padding(bottom = 20.dp)
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { onBack() }
            )
            Text(
                text = service.name,
                color = GraphiteWhite,
                fontSize = 26.sp,
                fontWeight = FontWeight.Light
            )
            Text(
                text = service.platform.name.lowercase(),
                color = GraphiteSoft,
                fontSize = 13.sp
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp)
                .padding(top = 24.dp, bottom = 40.dp)
        ) {
            HolstCard {
                Text("Link / Username", color = GraphiteSoft, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                HolstTextField(
                    value = link,
                    onValueChange = { link = it },
                    placeholder = "https://... atau @username"
                )
            }

            Spacer(Modifier.height(14.dp))

            HolstCard {
                Text("Jumlah", color = GraphiteSoft, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                HolstTextField(
                    value = quantity,
                    onValueChange = { quantity = it.filter { c -> c.isDigit() } },
                    placeholder = "Masukkan jumlah"
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Min ${service.minOrder}  •  Max ${service.maxOrder}",
                    color = GraphiteGray,
                    fontSize = 12.sp
                )
            }

            if (service.supportsCustomComment) {
                Spacer(Modifier.height(14.dp))
                HolstCard {
                    Text("Komentar Custom", color = GraphiteSoft, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    HolstTextField(
                        value = customComment,
                        onValueChange = { customComment = it },
                        placeholder = "Tulis komentar yang diinginkan...",
                        singleLine = false,
                        maxLines = 4
                    )
                }
            }

            Spacer(Modifier.height(28.dp))

            HolstButton(
                text = if (isLoading) "Memproses..." else "Kirim Order",
                enabled = !isLoading && link.isNotBlank() && quantity.isNotBlank(),
                onClick = {
                    val qty = quantity.toIntOrNull() ?: 0
                    isLoading = true
                    errorMessage = null
                    successMessage = null
                    scope.launch {
                        val result = repository.placeOrder(
                            serviceId = serviceId,
                            link = link,
                            quantity = qty,
                            customComment = customComment.ifBlank { null }
                        )
                        isLoading = false
                        result.fold(
                            onSuccess = {
                                successMessage = "Order berhasil • ${it.id}"
                                onOrderSuccess()
                            },
                            onFailure = {
                                errorMessage = it.message ?: "Gagal mengirim order"
                            }
                        )
                    }
                }
            )

            errorMessage?.let {
                Spacer(Modifier.height(16.dp))
                Text(text = it, color = GraphiteSoft, fontSize = 13.sp)
            }

            successMessage?.let {
                Spacer(Modifier.height(16.dp))
                Text(text = it, color = GraphiteWhite, fontSize = 13.sp)
            }
        }
    }
}
