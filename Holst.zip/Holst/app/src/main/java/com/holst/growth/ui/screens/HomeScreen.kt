package com.holst.growth.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.holst.growth.models.ServiceCatalog
import com.holst.growth.ui.components.HolstCard
import com.holst.growth.ui.components.SectionLabel
import com.holst.growth.ui.theme.*

@Composable
fun HomeScreen(
    onServiceClick: (String) -> Unit,
    onHistoryClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 22.dp)
                .padding(top = 52.dp, bottom = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Holst",
                        color = GraphiteWhite,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Light
                    )
                    Text(
                        text = "growth tools",
                        color = GraphiteSoft,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = "History",
                    color = GraphiteSoft,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) { onHistoryClick() }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 22.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionLabel("TikTok")
                Spacer(Modifier.height(10.dp))
            }

            items(ServiceCatalog.tiktok) { service ->
                HolstCard(onClick = { onServiceClick(service.id) }) {
                    Text(
                        text = service.name,
                        color = GraphiteWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = service.description,
                        color = GraphiteSoft,
                        fontSize = 13.sp
                    )
                }
            }

            item {
                Spacer(Modifier.height(20.dp))
                SectionLabel("Instagram")
                Spacer(Modifier.height(10.dp))
            }

            items(ServiceCatalog.instagram) { service ->
                HolstCard(onClick = { onServiceClick(service.id) }) {
                    Text(
                        text = service.name,
                        color = GraphiteWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = service.description,
                        color = GraphiteSoft,
                        fontSize = 13.sp
                    )
                }
            }

            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}
