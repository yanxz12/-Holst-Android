package com.holst.growth

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.holst.growth.ui.navigation.HolstNavGraph
import com.holst.growth.ui.theme.GraphiteBlack
import com.holst.growth.ui.theme.HolstTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HolstTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = GraphiteBlack
                ) {
                    HolstNavGraph()
                }
            }
        }
    }
}
