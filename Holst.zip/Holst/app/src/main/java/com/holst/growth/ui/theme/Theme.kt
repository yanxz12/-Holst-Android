package com.holst.growth.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val HolstColorScheme = darkColorScheme(
    primary = GraphiteWhite,
    onPrimary = GraphiteBlack,
    secondary = GraphiteSoft,
    background = GraphiteBlack,
    surface = GraphiteDark,
    onSurface = GraphiteLight,
    onBackground = GraphiteLight,
    outline = GraphiteMid
)

@Composable
fun HolstTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = HolstColorScheme,
        content = content
    )
}
