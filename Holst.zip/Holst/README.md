# Holst — Growth Tools

Elegant minimalist growth panel for TikTok & Instagram.
UI inspired by graphite palette.

## Palette
- #0E0E10  Background
- #232327  Surface / Card
- #3E3E45  Border
- #63636E  Secondary text
- #9A9AA6  Tertiary text
- #C9C9D2  Primary soft
- #F2F2F5  Highlight

## Features

### TikTok
- Followers
- Likes
- Like Comments
- Views
- Shares
- Favorites
- Live Stream viewers
- Reposts

### Instagram
- Followers
- Likes
- Like Comments
- Comments (custom text)
- Saves
- Shares
- Reposts

## How to open in Android Studio

1. Extract this folder
2. Open Android Studio → Open → select the `Holst` folder
3. Wait for Gradle sync
4. Run on emulator / device (API 26+)

## Structure

```
Holst/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/holst/growth/
│       │   ├── MainActivity.kt
│       │   ├── data/GrowthRepository.kt
│       │   ├── models/
│       │   ├── ui/
│       │   │   ├── components/
│       │   │   ├── navigation/
│       │   │   ├── screens/
│       │   │   └── theme/
│       └── res/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── gradle/wrapper/
```

## Replace Dummy Engine

File: `data/GrowthRepository.kt`

Ganti class `DummyGrowthRepository` dengan implementasi yang hit API SMM panel / private panel kamu.

## Build

```bash
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`
